---
name: FinReach AI Core
colors:
  surface: '#f5faf8'
  surface-dim: '#d6dbd9'
  surface-bright: '#f5faf8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f5f2'
  surface-container: '#eaefed'
  surface-container-high: '#e4e9e7'
  surface-container-highest: '#dee4e1'
  on-surface: '#171d1c'
  on-surface-variant: '#3d4947'
  inverse-surface: '#2c3130'
  inverse-on-surface: '#edf2f0'
  outline: '#6d7a77'
  outline-variant: '#bcc9c6'
  surface-tint: '#006a61'
  primary: '#00685f'
  on-primary: '#ffffff'
  primary-container: '#008378'
  on-primary-container: '#f4fffc'
  inverse-primary: '#6bd8cb'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#924628'
  on-tertiary: '#ffffff'
  tertiary-container: '#b05e3d'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#89f5e7'
  primary-fixed-dim: '#6bd8cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#773215'
  background: '#f5faf8'
  on-background: '#171d1c'
  surface-variant: '#dee4e1'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  sidebar_width: 260px
  topbar_height: 64px
  container_max_width: 1440px
  gutter: 24px
  component_gap: 16px
  padding_sm: 12px
  padding_md: 20px
  padding_lg: 32px
---

## Brand & Style
The design system is engineered for a high-stakes financial environment, balancing the rigor of institutional banking with the agility of modern AI SaaS. The brand personality is **authoritative, efficient, and transparent**, designed to instill confidence in loan officers and underwriters managing complex risk profiles.

The visual style is **Corporate / Modern**, prioritizing information density without sacrificing clarity. It utilizes a layered surface approach to organize data hierarchies, ensuring that the platform feels like a high-performance tool rather than a generic dashboard. The aesthetic avoids unnecessary decoration, focusing on functional aesthetics through precise alignment, refined borders, and a disciplined color application.

## Colors
The palette is anchored by **Deep Teal**, a color chosen for its association with financial stability and modern tech. **Slate Navy** provides a professional grounding for navigation and structural elements.

### Semantic & Status Palette
- **Primary (Deep Teal):** Used for primary actions, active navigation states, and brand-touchpoints.
- **Success/Warning/Danger:** Standardized for loan status (Approved/Pending/Rejected) and risk indicators.
- **Lead Temperature:**
  - **HOT:** Red-orange (High urgency).
  - **WARM:** Amber (Follow-up required).
  - **COLD:** Blue-gray (Low priority).
- **Messaging (WhatsApp):** Reserved strictly for chat-related actions and status indicators (Delivered/Read) to maintain platform-specific context.

## Typography
**Inter** is the sole typeface, utilized for its exceptional legibility in data-heavy interfaces. 

- **Headlines:** Use Bold or Semi-Bold weights with slight negative letter-spacing to maintain a compact, "newsroom" authority.
- **Body Text:** The 14px size is the workhorse for the system, providing a balance between density and readability.
- **Labels:** Uppercase labels are used for section headers within cards and metadata headers in tables to create clear visual anchors.
- **Numeric Data:** For KPI cards, use `display-lg` to ensure key metrics are the first thing a user sees.

## Layout & Spacing
The layout follows a **Fixed Sidebar + Fluid Content** model optimized for 1440px displays.

- **Structure:** A permanent 260px left sidebar handles primary navigation. The top bar (64px) provides global utility and context.
- **Grid:** Content is housed in a 12-column grid with 24px gutters.
- **Density:** We employ a "Variable Density" approach. Lists and tables use compact spacing (12px vertical padding), while dashboard overview cards use more generous spacing (24px - 32px) to prevent cognitive overload.
- **Breakpoints:** 
  - **Desktop (1280px+):** Full sidebar expanded.
  - **Tablet (768px - 1279px):** Sidebar collapses to icon-only rail; margins reduce to 16px.
  - **Mobile (<767px):** Bottom navigation or hamburger menu; single-column card stacking.

## Elevation & Depth
This design system uses **Tonal Layering** supplemented by subtle ambient shadows to define hierarchy.

- **Level 0 (Background):** `#F8FAFC` - The canvas.
- **Level 1 (Surface):** `#FFFFFF` - The primary card layer. Uses a 1px border of `#E2E8F0` and a soft, low-opacity shadow (Y: 1px, Blur: 3px, Opacity: 0.05).
- **Level 2 (Hover/Active):** Surfaces elevate slightly on hover (Y: 4px, Blur: 6px, Opacity: 0.1) to indicate interactivity.
- **Level 3 (Modals/Popovers):** Higher elevation with a 20% backdrop blur (glassmorphism) behind the overlay to maintain context of the underlying data.

## Shapes
The shape language is **Rounded**, utilizing an 8px base radius to soften the technical nature of the data while remaining professional.

- **Small Components (Buttons, Inputs, Badges):** 8px (rounded-md).
- **Large Components (Cards, Modals):** 12px (rounded-lg).
- **Status Pills:** Fully rounded (pill) to distinguish them from interactive buttons.

## Components

### Buttons
- **Primary:** Deep Teal background, white text. No gradient.
- **Secondary:** Slate Navy outline or ghost style for less prominent actions.
- **Tertiary:** Text-only with Deep Teal color for "Cancel" or "View All".

### Status Pills (Badges)
Pills use high-contrast solid backgrounds for lead temperature and soft tinted backgrounds for operational status.
- **Hot/Warm/Cold:** Solid background, white text.
- **Loan Status:** Tinted background (10% opacity of the semantic color) with high-contrast text of the same hue (e.g., Approved = Light Green BG, Dark Green Text).

### Tables
- **Row Styling:** No vertical borders. Light horizontal borders only (`#E2E8F0`).
- **Interaction:** Row hover uses a 2% tint of Deep Teal to highlight the active line.
- **Cell Content:** Use `body-sm` for data; `label-md` for column headers.

### KPI Cards
- **Structure:** Headline (Label-md) -> Large Number (Display-lg) -> Trend Indicator (Label-sm with icon).
- **Visuals:** Include a subtle micro-sparkline in Deep Teal for 7-day trends.

### Messaging (WhatsApp)
- **Bubble Inbound:** White surface, Slate Navy text, 1px border.
- **Bubble Outbound:** Primary Green (`#25D366`), white text.
- **Meta:** Include double-tick icons for delivery status (Grey = Sent, Blue = Read).

### Timeline
- **Track:** 2px vertical rail in `#E2E8F0`.
- **Nodes:** 8px circles. Active nodes use Primary Teal; historical nodes use Slate Navy; pending nodes use a hollow outline.